# Concept-Object-Project

This is a project to create a game opposing 4 teams having for objective to collect messages on a map, the teams are
represented by 4 arenas from Pokemon and the messages are represented by Pokemon.

![image](https://mvistatic.com/photosmvi/2021/07/01/P27207164D4445551G_crop_640-330_.jpg)

## Team

The team is composed of 6 members :

- DEBEURME Nicolas
- DE ROQUEMAUREL Swann
- RANC Mathieu
- FILIPOVIC Andrea
- RADOICIC Maja
- LJUBOJEVIC Marta

## Installation

The file to run is src/main/java/com/example/conceptobjectproject/GameManager.java

```bash
java ./src/main/java/com/example/conceptobjectproject/GameManager.java
```
