package com.example.conceptobjectproject;

import Enums.ZoneTypes;

public class SimulationObject {
    public javafx.scene.Node graphObj;
    public ZoneTypes objectType;
}
